"""
Sigma PaperPlane 测试模块
测试各个组件的功能
"""

import sys
import os
import unittest
import numpy as np

# 添加项目根目录到路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from src.paper_plane_generator import PaperPlaneGenerator
from src.fluid_simulation import FluidSimulation
from src.optimization import GeneticOptimizer
from src.visualization import Visualization

class TestPaperPlaneGenerator(unittest.TestCase):
    """测试纸飞机生成器"""
    
    def setUp(self):
        self.generator = PaperPlaneGenerator()
    
    def test_generate_random_plane(self):
        """测试随机纸飞机生成"""
        plane = self.generator.generate_random_plane()
        
        # 检查基本参数
        self.assertIn('type', plane)
        self.assertIn('wing_span', plane)
        self.assertIn('body_length', plane)
        self.assertIn('fold_lines', plane)
        
        # 检查参数范围
        self.assertGreater(plane['wing_span'], 0)
        self.assertGreater(plane['body_length'], 0)
        self.assertGreaterEqual(plane['weight_distribution'], 0)
        self.assertLessEqual(plane['weight_distribution'], 1)
    
    def test_plane_geometry(self):
        """测试几何形状生成"""
        plane = self.generator._generate_classic_plane()
        geometry = self.generator.get_plane_geometry(plane)
        
        # 检查几何信息
        self.assertIn('vertices', geometry)
        self.assertIn('edges', geometry)
        self.assertIn('faces', geometry)
        self.assertIn('center_of_mass', geometry)
        self.assertIn('surface_area', geometry)
        
        # 检查顶点数量
        self.assertGreater(len(geometry['vertices']), 0)
        
        # 检查表面积
        self.assertGreater(geometry['surface_area'], 0)
    
    def test_all_plane_types(self):
        """测试所有纸飞机类型"""
        plane_types = ['classic', 'delta', 'glider', 'stunt', 'long_distance']
        
        for plane_type in plane_types:
            if plane_type == 'classic':
                plane = self.generator._generate_classic_plane()
            elif plane_type == 'delta':
                plane = self.generator._generate_delta_plane()
            elif plane_type == 'glider':
                plane = self.generator._generate_glider_plane()
            elif plane_type == 'stunt':
                plane = self.generator._generate_stunt_plane()
            else:
                plane = self.generator._generate_long_distance_plane()
            
            self.assertEqual(plane['type'], plane_type)
            self.assertGreater(len(plane['fold_lines']), 0)

class TestFluidSimulation(unittest.TestCase):
    """测试流体仿真"""
    
    def setUp(self):
        self.simulator = FluidSimulation()
        self.generator = PaperPlaneGenerator()
    
    def test_simulation_initialization(self):
        """测试仿真器初始化"""
        self.assertEqual(self.simulator.air_density, 1.225)
        self.assertEqual(self.simulator.gravity, 9.81)
    
    def test_mass_calculation(self):
        """测试质量计算"""
        plane = self.generator._generate_classic_plane()
        geometry = self.generator.get_plane_geometry(plane)
        
        mass = self.simulator._calculate_mass(geometry)
        self.assertGreater(mass, 0)
        self.assertLess(mass, 0.1)  # 纸飞机质量应该很小
    
    def test_aerodynamic_coefficients(self):
        """测试气动系数计算"""
        plane = self.generator._generate_classic_plane()
        geometry = self.generator.get_plane_geometry(plane)
        
        coeffs = self.simulator._calculate_aerodynamic_coefficients(geometry)
        
        # 检查基本气动系数
        required_coeffs = ['S', 'b', 'c', 'CL0', 'CLa', 'CL_max', 'CD0', 'CD_alpha']
        for coeff in required_coeffs:
            self.assertIn(coeff, coeffs)
            self.assertIsInstance(coeffs[coeff], (int, float))
    
    def test_basic_simulation(self):
        """测试基本仿真"""
        plane = self.generator._generate_classic_plane()
        geometry = self.generator.get_plane_geometry(plane)
        
        initial_conditions = {
            'position': [0, 0, 2.0],
            'velocity': [6.0, 0, 0],
            'orientation': [10, 0, 0]
        }
        
        wind_conditions = {
            'velocity': [0, 0, 0],
            'gradient': 0.0,
            'turbulence': 0.0
        }
        
        result = self.simulator.simulate_flight(
            geometry, initial_conditions, wind_conditions,
            simulation_time=2.0  # 使用较短的仿真时间
        )
        
        # 检查仿真结果
        self.assertIn('trajectory', result)
        self.assertIn('flight_distance', result)
        self.assertIn('flight_time', result)
        self.assertIn('stability_metrics', result)
        
        # 检查轨迹数据
        self.assertGreater(len(result['trajectory']), 0)
        self.assertIsInstance(result['flight_distance'], (int, float))
        self.assertIsInstance(result['flight_time'], (int, float))

class TestGeneticOptimizer(unittest.TestCase):
    """测试遗传算法优化器"""
    
    def setUp(self):
        self.optimizer = GeneticOptimizer(
            population_size=10,  # 使用较小的种群进行测试
            mutation_rate=0.1,
            crossover_rate=0.8,
            elite_count=2
        )
    
    def test_optimizer_initialization(self):
        """测试优化器初始化"""
        self.assertEqual(self.optimizer.population_size, 10)
        self.assertEqual(self.optimizer.mutation_rate, 0.1)
        self.assertEqual(self.optimizer.crossover_rate, 0.8)
        self.assertEqual(self.optimizer.elite_count, 2)
    
    def test_population_initialization(self):
        """测试种群初始化"""
        population = self.optimizer._initialize_population()
        
        self.assertEqual(len(population), self.optimizer.population_size)
        
        # 检查种群中的个体
        for individual in population:
            self.assertIn('type', individual)
            self.assertIn('wing_span', individual)
            self.assertIn('body_length', individual)
    
    def test_fitness_evaluation(self):
        """测试适应度评估"""
        population = self.optimizer._initialize_population()
        fitness_scores = self.optimizer._evaluate_population(population, 'distance')
        
        self.assertEqual(len(fitness_scores), len(population))
        
        # 检查适应度分数
        for fitness in fitness_scores:
            self.assertIsInstance(fitness, (int, float))
            self.assertGreaterEqual(fitness, 0)
    
    def test_crossover(self):
        """测试交叉操作"""
        parent1 = self.optimizer.generator._generate_classic_plane()
        parent2 = self.optimizer.generator._generate_delta_plane()
        
        child1, child2 = self.optimizer._crossover(parent1, parent2)
        
        # 检查子代参数
        for child in [child1, child2]:
            self.assertIn('type', child)
            self.assertIn('wing_span', child)
            self.assertIn('body_length', child)
    
    def test_mutation(self):
        """测试变异操作"""
        individual = self.optimizer.generator._generate_classic_plane()
        original_wing_span = individual['wing_span']
        
        mutated = self.optimizer._mutate(individual)
        
        # 检查变异后的个体
        self.assertIn('type', mutated)
        self.assertIn('wing_span', mutated)
        
        # 变异可能改变参数，也可能不变
        # 这里只检查结构完整性

class TestVisualization(unittest.TestCase):
    """测试可视化模块"""
    
    def setUp(self):
        self.visualizer = Visualization()
        self.generator = PaperPlaneGenerator()
        self.simulator = FluidSimulation()
    
    def test_visualization_initialization(self):
        """测试可视化工具初始化"""
        self.assertEqual(len(self.visualizer.colors), 5)
        self.assertIsInstance(self.visualizer.colors, list)
    
    def test_optimization_progress_plot(self):
        """测试优化进度图生成"""
        # 创建模拟的优化结果
        optimization_result = {
            'best_fitness_history': [0.1, 0.3, 0.5, 0.7, 0.9],
            'avg_fitness_history': [0.05, 0.2, 0.4, 0.6, 0.8]
        }
        
        # 测试函数是否能正常执行（不检查具体绘图）
        try:
            self.visualizer.plot_optimization_progress(optimization_result)
            plot_success = True
        except Exception as e:
            plot_success = False
            print(f"绘图测试失败: {e}")
        
        self.assertTrue(plot_success)
    
    def test_fold_pattern_plot(self):
        """测试折叠图案生成"""
        plane = self.generator._generate_classic_plane()
        
        # 测试函数是否能正常执行
        try:
            self.visualizer.plot_fold_pattern(plane)
            plot_success = True
        except Exception as e:
            plot_success = False
            print(f"折叠图案测试失败: {e}")
        
        self.assertTrue(plot_success)

def run_all_tests():
    """运行所有测试"""
    # 创建测试套件
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # 添加测试类
    suite.addTests(loader.loadTestsFromTestCase(TestPaperPlaneGenerator))
    suite.addTests(loader.loadTestsFromTestCase(TestFluidSimulation))
    suite.addTests(loader.loadTestsFromTestCase(TestGeneticOptimizer))
    suite.addTests(loader.loadTestsFromTestCase(TestVisualization))
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

if __name__ == "__main__":
    print("运行 Sigma PaperPlane 测试套件...")
    print("=" * 50)
    
    success = run_all_tests()
    
    print("=" * 50)
    if success:
        print("所有测试通过！")
    else:
        print("部分测试失败！")
    
    sys.exit(0 if success else 1)
