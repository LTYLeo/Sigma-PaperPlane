"""
纸飞机折叠形状生成器
负责生成各种纸飞机的几何形状和折叠参数
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
import random

class PaperPlaneGenerator:
    """纸飞机形状生成器"""
    
    def __init__(self, paper_size: Tuple[float, float] = (29.7, 21.0)):
        """
        初始化纸飞机生成器
        
        Args:
            paper_size: A4纸尺寸 (长, 宽) 单位: cm
        """
        self.paper_length, self.paper_width = paper_size
        self.basic_shapes = ['classic', 'delta', 'glider', 'stunt', 'long_distance']
        
    def generate_random_plane(self) -> Dict:
        """
        生成随机纸飞机参数
        
        Returns:
            包含纸飞机参数的字典
        """
        shape_type = random.choice(self.basic_shapes)
        
        if shape_type == 'classic':
            return self._generate_classic_plane()
        elif shape_type == 'delta':
            return self._generate_delta_plane()
        elif shape_type == 'glider':
            return self._generate_glider_plane()
        elif shape_type == 'stunt':
            return self._generate_stunt_plane()
        else:  # long_distance
            return self._generate_long_distance_plane()
    
    def _generate_classic_plane(self) -> Dict:
        """生成经典纸飞机参数"""
        return {
            'type': 'classic',
            'wing_span': random.uniform(0.6, 0.8) * self.paper_width,
            'body_length': random.uniform(0.7, 0.9) * self.paper_length,
            'nose_angle': random.uniform(20, 40),  # 度
            'wing_angle': random.uniform(5, 15),   # 度
            'fold_lines': self._generate_classic_fold_lines(),
            'weight_distribution': random.uniform(0.3, 0.7)
        }
    
    def _generate_delta_plane(self) -> Dict:
        """生成三角翼纸飞机参数"""
        return {
            'type': 'delta',
            'wing_span': random.uniform(0.7, 0.9) * self.paper_width,
            'body_length': random.uniform(0.6, 0.8) * self.paper_length,
            'nose_angle': random.uniform(30, 50),
            'wing_sweep_angle': random.uniform(40, 60),
            'fold_lines': self._generate_delta_fold_lines(),
            'weight_distribution': random.uniform(0.4, 0.8)
        }
    
    def _generate_glider_plane(self) -> Dict:
        """生成滑翔机纸飞机参数"""
        return {
            'type': 'glider',
            'wing_span': random.uniform(0.8, 1.0) * self.paper_width,
            'body_length': random.uniform(0.5, 0.7) * self.paper_length,
            'nose_angle': random.uniform(15, 30),
            'wing_aspect_ratio': random.uniform(2.0, 4.0),
            'fold_lines': self._generate_glider_fold_lines(),
            'weight_distribution': random.uniform(0.2, 0.5)
        }
    
    def _generate_stunt_plane(self) -> Dict:
        """生成特技纸飞机参数"""
        return {
            'type': 'stunt',
            'wing_span': random.uniform(0.5, 0.7) * self.paper_width,
            'body_length': random.uniform(0.8, 1.0) * self.paper_length,
            'nose_angle': random.uniform(10, 25),
            'wing_dihedral': random.uniform(5, 20),
            'fold_lines': self._generate_stunt_fold_lines(),
            'weight_distribution': random.uniform(0.6, 0.9)
        }
    
    def _generate_long_distance_plane(self) -> Dict:
        """生成长距离纸飞机参数"""
        return {
            'type': 'long_distance',
            'wing_span': random.uniform(0.9, 1.1) * self.paper_width,
            'body_length': random.uniform(0.4, 0.6) * self.paper_length,
            'nose_angle': random.uniform(25, 35),
            'wing_camber': random.uniform(0.02, 0.08),
            'fold_lines': self._generate_long_distance_fold_lines(),
            'weight_distribution': random.uniform(0.1, 0.4)
        }
    
    def _generate_classic_fold_lines(self) -> List[Tuple]:
        """生成经典纸飞机的折叠线"""
        return [
            ('center_fold', 0.5, 0, 0.5, 1),
            ('nose_fold', 0.3, 0.2, 0.7, 0.2),
            ('wing_fold', 0.2, 0.4, 0.8, 0.4)
        ]
    
    def _generate_delta_fold_lines(self) -> List[Tuple]:
        """生成三角翼纸飞机的折叠线"""
        return [
            ('center_fold', 0.5, 0, 0.5, 1),
            ('sweep_fold', 0.2, 0.3, 0.8, 0.3),
            ('wing_tip_fold', 0.1, 0.6, 0.9, 0.6)
        ]
    
    def _generate_glider_fold_lines(self) -> List[Tuple]:
        """生成滑翔机纸飞机的折叠线"""
        return [
            ('center_fold', 0.5, 0, 0.5, 1),
            ('high_wing_fold', 0.4, 0.1, 0.6, 0.1),
            ('tail_fold', 0.3, 0.8, 0.7, 0.8)
        ]
    
    def _generate_stunt_fold_lines(self) -> List[Tuple]:
        """生成特技纸飞机的折叠线"""
        return [
            ('center_fold', 0.5, 0, 0.5, 1),
            ('diagonal_fold', 0.2, 0.2, 0.8, 0.5),
            ('reverse_fold', 0.3, 0.7, 0.7, 0.7)
        ]
    
    def _generate_long_distance_fold_lines(self) -> List[Tuple]:
        """生成长距离纸飞机的折叠线"""
        return [
            ('center_fold', 0.5, 0, 0.5, 1),
            ('swept_wing_fold', 0.4, 0.1, 0.6, 0.1),
            ('camber_fold', 0.45, 0.3, 0.55, 0.3)
        ]
    
    def get_plane_geometry(self, plane_params: Dict) -> Dict:
        """
        根据参数生成纸飞机的几何形状
        
        Args:
            plane_params: 纸飞机参数
            
        Returns:
            包含几何信息的字典
        """
        geometry = {
            'vertices': [],
            'edges': [],
            'faces': [],
            'center_of_mass': (0, 0, 0),
            'surface_area': 0.0
        }
        
        # 简化的几何生成逻辑
        if plane_params['type'] == 'classic':
            geometry = self._create_classic_geometry(plane_params)
        elif plane_params['type'] == 'delta':
            geometry = self._create_delta_geometry(plane_params)
        elif plane_params['type'] == 'glider':
            geometry = self._create_glider_geometry(plane_params)
        elif plane_params['type'] == 'stunt':
            geometry = self._create_stunt_geometry(plane_params)
        else:  # long_distance
            geometry = self._create_long_distance_geometry(plane_params)
            
        return geometry
    
    def _create_classic_geometry(self, params: Dict) -> Dict:
        """创建经典纸飞机的几何形状"""
        vertices = [
            (0, 0, 0),  # 鼻尖
            (-params['wing_span']/2, params['body_length']*0.3, 0),  # 左翼尖
            (params['wing_span']/2, params['body_length']*0.3, 0),   # 右翼尖
            (0, params['body_length'], 0)  # 尾部
        ]
        
        return {
            'vertices': vertices,
            'edges': [(0,1), (0,2), (1,3), (2,3)],
            'faces': [(0,1,3), (0,2,3)],
            'center_of_mass': (0, params['body_length']*params['weight_distribution'], 0),
            'surface_area': params['wing_span'] * params['body_length'] * 0.5
        }
    
    def _create_delta_geometry(self, params: Dict) -> Dict:
        """创建三角翼纸飞机的几何形状"""
        vertices = [
            (0, 0, 0),  # 鼻尖
            (-params['wing_span']/2, params['body_length']*0.6, 0),  # 左翼后缘
            (params['wing_span']/2, params['body_length']*0.6, 0),   # 右翼后缘
            (0, params['body_length'], 0)  # 尾部
        ]
        
        return {
            'vertices': vertices,
            'edges': [(0,1), (0,2), (1,3), (2,3)],
            'faces': [(0,1,3), (0,2,3)],
            'center_of_mass': (0, params['body_length']*params['weight_distribution'], 0),
            'surface_area': params['wing_span'] * params['body_length'] * 0.6
        }
    
    def _create_glider_geometry(self, params: Dict) -> Dict:
        """创建滑翔机纸飞机的几何形状"""
        vertices = [
            (0, 0, 0),  # 鼻尖
            (-params['wing_span']/2, params['body_length']*0.2, 0),  # 左翼前缘
            (params['wing_span']/2, params['body_length']*0.2, 0),   # 右翼前缘
            (-params['wing_span']/3, params['body_length'], 0),      # 左尾
            (params['wing_span']/3, params['body_length'], 0)        # 右尾
        ]
        
        return {
            'vertices': vertices,
            'edges': [(0,1), (0,2), (1,3), (2,4), (3,4)],
            'faces': [(0,1,3,4,2)],
            'center_of_mass': (0, params['body_length']*params['weight_distribution'], 0),
            'surface_area': params['wing_span'] * params['body_length'] * 0.7
        }
    
    def _create_stunt_geometry(self, params: Dict) -> Dict:
        """创建特技纸飞机的几何形状"""
        vertices = [
            (0, 0, 0),  # 鼻尖
            (-params['wing_span']/2, params['body_length']*0.4, 0),  # 左翼
            (params['wing_span']/2, params['body_length']*0.4, 0),   # 右翼
            (0, params['body_length'], 0)  # 尾部
        ]
        
        return {
            'vertices': vertices,
            'edges': [(0,1), (0,2), (1,3), (2,3)],
            'faces': [(0,1,3), (0,2,3)],
            'center_of_mass': (0, params['body_length']*params['weight_distribution'], 0),
            'surface_area': params['wing_span'] * params['body_length'] * 0.4
        }
    
    def _create_long_distance_geometry(self, params: Dict) -> Dict:
        """生成长距离纸飞机的几何形状"""
        vertices = [
            (0, 0, 0),  # 鼻尖
            (-params['wing_span']/2, params['body_length']*0.1, 0),  # 左翼前缘
            (params['wing_span']/2, params['body_length']*0.1, 0),   # 右翼前缘
            (-params['wing_span']/2, params['body_length']*0.8, 0),  # 左翼后缘
            (params['wing_span']/2, params['body_length']*0.8, 0),   # 右翼后缘
            (0, params['body_length'], 0)  # 尾部
        ]
        
        return {
            'vertices': vertices,
            'edges': [(0,1), (0,2), (1,3), (2,4), (3,5), (4,5)],
            'faces': [(0,1,3,5,4,2)],
            'center_of_mass': (0, params['body_length']*params['weight_distribution'], 0),
            'surface_area': params['wing_span'] * params['body_length'] * 0.8
        }
