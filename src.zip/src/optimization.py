"""
优化算法模块
使用遗传算法优化纸飞机折叠形状
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Callable
import random
from tqdm import tqdm
from .paper_plane_generator import PaperPlaneGenerator
from .fluid_simulation import FluidSimulation

class GeneticOptimizer:
    """遗传算法优化器"""
    
    def __init__(self, population_size: int = 50, 
                 mutation_rate: float = 0.1,
                 crossover_rate: float = 0.8,
                 elite_count: int = 5):
        """
        初始化遗传算法优化器
        
        Args:
            population_size: 种群大小
            mutation_rate: 变异率
            crossover_rate: 交叉率
            elite_count: 精英个体数量
        """
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.elite_count = elite_count
        
        self.generator = PaperPlaneGenerator()
        self.simulator = FluidSimulation()
        
        # 定义测试条件
        self.test_conditions = [
            # 无风条件
            {
                'name': '无风',
                'wind_velocity': [0, 0, 0],
                'launch_speed': 6.0,
                'launch_angle': 10,
                'weight': 1.0
            },
            # 顺风条件
            {
                'name': '顺风',
                'wind_velocity': [3, 0, 0],
                'launch_speed': 5.0,
                'launch_angle': 5,
                'weight': 0.8
            },
            # 逆风条件
            {
                'name': '逆风',
                'wind_velocity': [-2, 0, 0],
                'launch_speed': 7.0,
                'launch_angle': 15,
                'weight': 1.2
            },
            # 侧风条件
            {
                'name': '侧风',
                'wind_velocity': [0, 2, 0],
                'launch_speed': 6.0,
                'launch_angle': 10,
                'weight': 1.1
            }
        ]
    
    def optimize(self, generations: int = 100, 
                objective: str = 'distance') -> Dict:
        """
        运行遗传算法优化
        
        Args:
            generations: 进化代数
            objective: 优化目标 ('distance', 'stability', 'balanced')
            
        Returns:
            优化结果
        """
        # 初始化种群
        population = self._initialize_population()
        best_fitness_history = []
        avg_fitness_history = []
        best_individual_history = []
        
        print(f"开始遗传算法优化，种群大小: {self.population_size}, 代数: {generations}")
        
        for generation in tqdm(range(generations)):
            # 评估适应度
            fitness_scores = self._evaluate_population(population, objective)
            
            # 记录统计信息
            best_fitness = max(fitness_scores)
            avg_fitness = np.mean(fitness_scores)
            best_idx = np.argmax(fitness_scores)
            best_individual = population[best_idx]
            
            best_fitness_history.append(best_fitness)
            avg_fitness_history.append(avg_fitness)
            best_individual_history.append(best_individual.copy())
            
            # 选择、交叉、变异
            new_population = self._create_new_population(population, fitness_scores)
            population = new_population
            
            # 每10代输出进度
            if generation % 10 == 0:
                print(f"第{generation}代 - 最佳适应度: {best_fitness:.3f}, 平均适应度: {avg_fitness:.3f}")
        
        # 返回最终结果
        final_fitness = self._evaluate_population(population, objective)
        best_idx = np.argmax(final_fitness)
        best_individual = population[best_idx]
        
        # 对最佳个体进行详细评估
        detailed_evaluation = self._evaluate_individual_detailed(best_individual)
        
        return {
            'best_individual': best_individual,
            'best_fitness': final_fitness[best_idx],
            'best_fitness_history': best_fitness_history,
            'avg_fitness_history': avg_fitness_history,
            'best_individual_history': best_individual_history,
            'detailed_evaluation': detailed_evaluation,
            'final_population': population
        }
    
    def _initialize_population(self) -> List[Dict]:
        """初始化种群"""
        population = []
        for _ in range(self.population_size):
            individual = self.generator.generate_random_plane()
            population.append(individual)
        return population
    
    def _evaluate_population(self, population: List[Dict], 
                           objective: str) -> List[float]:
        """
        评估种群中每个个体的适应度
        
        Args:
            population: 种群
            objective: 优化目标
            
        Returns:
            适应度分数列表
        """
        fitness_scores = []
        
        for individual in population:
            fitness = self._evaluate_individual(individual, objective)
            fitness_scores.append(fitness)
            
        return fitness_scores
    
    def _evaluate_individual(self, individual: Dict, objective: str) -> float:
        """
        评估单个个体的适应度
        
        Args:
            individual: 个体参数
            objective: 优化目标
            
        Returns:
            适应度分数
        """
        # 在多条件下测试
        multi_test_results = self.simulator.test_multiple_conditions(
            individual, self.test_conditions
        )
        
        # 计算综合分数
        total_score = 0.0
        total_weight = 0.0
        
        for test_name, test_result in multi_test_results.items():
            result = test_result['result']
            weight = test_result['conditions'].get('weight', 1.0)
            
            if objective == 'distance':
                score = result['flight_distance']
            elif objective == 'stability':
                score = result['stability_metrics']['overall_stability']
            else:  # balanced
                # 平衡距离和稳定性
                distance_score = result['flight_distance'] / 20.0  # 归一化
                stability_score = result['stability_metrics']['overall_stability']
                score = 0.7 * distance_score + 0.3 * stability_score
            
            # 如果飞行失败，给予惩罚
            if not result['success']:
                score *= 0.1
                
            total_score += score * weight
            total_weight += weight
        
        return total_score / total_weight if total_weight > 0 else 0.0
    
    def _evaluate_individual_detailed(self, individual: Dict) -> Dict:
        """
        对个体进行详细评估
        
        Args:
            individual: 个体参数
            
        Returns:
            详细评估结果
        """
        detailed_results = {}
        
        for condition in self.test_conditions:
            geometry = self.generator.get_plane_geometry(individual)
            
            initial_conditions = {
                'position': [0, 0, condition.get('launch_height', 2.0)],
                'velocity': [condition.get('launch_speed', 6.0), 0, 0],
                'orientation': [condition.get('launch_angle', 10), 0, 0]
            }
            
            wind_conditions = {
                'velocity': condition['wind_velocity'],
                'gradient': condition.get('wind_gradient', 0.0),
                'turbulence': condition.get('turbulence', 0.0)
            }
            
            result = self.simulator.simulate_flight(
                geometry, initial_conditions, wind_conditions
            )
            
            detailed_results[condition['name']] = {
                'flight_distance': result['flight_distance'],
                'flight_time': result['flight_time'],
                'stability_metrics': result['stability_metrics'],
                'success': result['success'],
                'trajectory': result['trajectory']
            }
        
        return detailed_results
    
    def _create_new_population(self, population: List[Dict], 
                             fitness_scores: List[float]) -> List[Dict]:
        """
        创建新一代种群
        
        Args:
            population: 当前种群
            fitness_scores: 适应度分数
            
        Returns:
            新一代种群
        """
        new_population = []
        
        # 精英选择
        elite_indices = np.argsort(fitness_scores)[-self.elite_count:]
        for idx in elite_indices:
            new_population.append(population[idx].copy())
        
        # 轮盘赌选择
        while len(new_population) < self.population_size:
            # 选择父母
            parent1 = self._select_parent(population, fitness_scores)
            parent2 = self._select_parent(population, fitness_scores)
            
            # 交叉
            if random.random() < self.crossover_rate:
                child1, child2 = self._crossover(parent1, parent2)
            else:
                child1, child2 = parent1.copy(), parent2.copy()
            
            # 变异
            child1 = self._mutate(child1)
            child2 = self._mutate(child2)
            
            new_population.extend([child1, child2])
        
        # 如果超出种群大小，随机移除多余的个体
        return new_population[:self.population_size]
    
    def _select_parent(self, population: List[Dict], 
                      fitness_scores: List[float]) -> Dict:
        """
        使用轮盘赌选择父母
        
        Args:
            population: 种群
            fitness_scores: 适应度分数
            
        Returns:
            选择的父母个体
        """
        # 确保所有适应度为正
        min_fitness = min(fitness_scores)
        adjusted_fitness = [f - min_fitness + 0.1 for f in fitness_scores]
        
        total_fitness = sum(adjusted_fitness)
        selection_prob = [f / total_fitness for f in adjusted_fitness]
        
        return random.choices(population, weights=selection_prob)[0]
    
    def _crossover(self, parent1: Dict, parent2: Dict) -> Tuple[Dict, Dict]:
        """
        交叉操作
        
        Args:
            parent1: 父母1
            parent2: 父母2
            
        Returns:
            两个子代个体
        """
        child1 = parent1.copy()
        child2 = parent2.copy()
        
        # 对数值参数进行交叉
        numeric_params = ['wing_span', 'body_length', 'nose_angle', 'weight_distribution']
        
        for param in numeric_params:
            if param in parent1 and param in parent2:
                # 算术交叉
                alpha = random.random()
                child1[param] = alpha * parent1[param] + (1 - alpha) * parent2[param]
                child2[param] = alpha * parent2[param] + (1 - alpha) * parent1[param]
        
        # 类型交叉 (50%概率交换类型)
        if random.random() < 0.5:
            child1['type'], child2['type'] = child2['type'], child1['type']
            # 同时交换对应的折叠线
            child1['fold_lines'], child2['fold_lines'] = child2['fold_lines'], child1['fold_lines']
        
        return child1, child2
    
    def _mutate(self, individual: Dict) -> Dict:
        """
        变异操作
        
        Args:
            individual: 要变异的个体
            
        Returns:
            变异后的个体
        """
        mutated = individual.copy()
        
        # 数值参数变异
        if random.random() < self.mutation_rate:
            param = random.choice(['wing_span', 'body_length', 'nose_angle', 'weight_distribution'])
            if param in mutated:
                # 高斯变异
                current_value = mutated[param]
                mutation_strength = 0.1 * current_value  # 10%的变异强度
                mutated[param] = max(0.1, current_value + random.gauss(0, mutation_strength))
        
        # 类型变异
        if random.random() < self.mutation_rate * 0.5:
            new_type = random.choice(self.generator.basic_shapes)
            if new_type != mutated['type']:
                mutated['type'] = new_type
                # 更新对应的折叠线
                if new_type == 'classic':
                    mutated['fold_lines'] = self.generator._generate_classic_fold_lines()
                elif new_type == 'delta':
                    mutated['fold_lines'] = self.generator._generate_delta_fold_lines()
                elif new_type == 'glider':
                    mutated['fold_lines'] = self.generator._generate_glider_fold_lines()
                elif new_type == 'stunt':
                    mutated['fold_lines'] = self.generator._generate_stunt_fold_lines()
                else:  # long_distance
                    mutated['fold_lines'] = self.generator._generate_long_distance_fold_lines()
        
        return mutated
    
    def get_optimization_summary(self, optimization_result: Dict) -> Dict:
        """
        获取优化结果摘要
        
        Args:
            optimization_result: 优化结果
            
        Returns:
            优化摘要
        """
        best_individual = optimization_result['best_individual']
        detailed_eval = optimization_result['detailed_evaluation']
        
        summary = {
            'best_plane_type': best_individual['type'],
            'best_fitness': optimization_result['best_fitness'],
            'performance_by_condition': {},
            'key_parameters': {
                'wing_span': best_individual['wing_span'],
                'body_length': best_individual['body_length'],
                'nose_angle': best_individual['nose_angle'],
                'weight_distribution': best_individual['weight_distribution']
            }
        }
        
        # 计算各条件下的性能
        for condition_name, result in detailed_eval.items():
            summary['performance_by_condition'][condition_name] = {
                'flight_distance': result['flight_distance'],
                'flight_time': result['flight_time'],
                'stability': result['stability_metrics']['overall_stability'],
                'success': result['success']
            }
        
        return summary
