"""
Sigma PaperPlane - 智能纸飞机优化系统

一个基于人工智能的纸飞机折叠优化系统，通过生成不同的折叠形状
并在流体仿真中测试飞行性能，找到最优的折叠方案。
"""

__version__ = "1.0.0"
__author__ = "Sigma PaperPlane Team"

from .paper_plane_generator import PaperPlaneGenerator
from .fluid_simulation import FluidSimulation
from .optimization import GeneticOptimizer
from .visualization import Visualization

__all__ = [
    'PaperPlaneGenerator',
    'FluidSimulation', 
    'GeneticOptimizer',
    'Visualization'
]
