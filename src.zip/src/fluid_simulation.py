"""
流体动力学仿真模块
模拟纸飞机在不同风速和条件下的飞行性能
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from scipy.integrate import solve_ivp
import math

class FluidSimulation:
    """流体动力学仿真器"""
    
    def __init__(self, air_density: float = 1.225, gravity: float = 9.81):
        """
        初始化流体仿真器
        
        Args:
            air_density: 空气密度 (kg/m³)
            gravity: 重力加速度 (m/s²)
        """
        self.air_density = air_density
        self.gravity = gravity
        
    def simulate_flight(self, plane_geometry: Dict, 
                       initial_conditions: Dict,
                       wind_conditions: Dict,
                       simulation_time: float = 10.0) -> Dict:
        """
        模拟纸飞机飞行
        
        Args:
            plane_geometry: 纸飞机几何信息
            initial_conditions: 初始条件
            wind_conditions: 风况条件
            simulation_time: 仿真时间 (秒)
            
        Returns:
            飞行仿真结果
        """
        # 提取纸飞机参数
        mass = self._calculate_mass(plane_geometry)
        aerodynamic_coeffs = self._calculate_aerodynamic_coefficients(plane_geometry)
        
        # 初始状态向量: [x, y, z, vx, vy, vz, pitch, roll, yaw, pitch_rate, roll_rate, yaw_rate]
        initial_state = np.array([
            initial_conditions['position'][0],  # x
            initial_conditions['position'][1],  # y  
            initial_conditions['position'][2],  # z
            initial_conditions['velocity'][0],  # vx
            initial_conditions['velocity'][1],  # vy
            initial_conditions['velocity'][2],  # vz
            initial_conditions['orientation'][0],  # pitch
            initial_conditions['orientation'][1],  # roll
            initial_conditions['orientation'][2],  # yaw
            0, 0, 0  # 角速度初始为0
        ])
        
        # 求解微分方程
        t_span = (0, simulation_time)
        t_eval = np.linspace(0, simulation_time, 1000)
        
        solution = solve_ivp(
            self._flight_dynamics,
            t_span,
            initial_state,
            t_eval=t_eval,
            args=(mass, aerodynamic_coeffs, wind_conditions),
            method='RK45'
        )
        
        return self._process_simulation_results(solution, plane_geometry)
    
    def _flight_dynamics(self, t: float, state: np.ndarray, 
                        mass: float, aero_coeffs: Dict, 
                        wind_conditions: Dict) -> np.ndarray:
        """
        飞行动力学方程
        
        Args:
            t: 时间
            state: 状态向量
            mass: 质量
            aero_coeffs: 气动系数
            wind_conditions: 风况
            
        Returns:
            状态导数
        """
        # 解包状态向量
        x, y, z, vx, vy, vz, pitch, roll, yaw, p, q, r = state
        
        # 计算相对风速
        wind_velocity = self._get_wind_velocity(z, wind_conditions)
        v_rel_x = vx - wind_velocity[0]
        v_rel_y = vy - wind_velocity[1]
        v_rel_z = vz - wind_velocity[2]
        
        # 计算空速和攻角
        airspeed = math.sqrt(v_rel_x**2 + v_rel_y**2 + v_rel_z**2)
        if airspeed > 0.1:  # 避免除以零
            alpha = math.atan2(v_rel_z, v_rel_x)  # 攻角
            beta = math.asin(v_rel_y / airspeed)   # 侧滑角
        else:
            alpha = 0
            beta = 0
        
        # 计算气动力和力矩
        forces, moments = self._calculate_aerodynamic_forces(
            airspeed, alpha, beta, aero_coeffs, mass
        )
        
        # 计算重力
        gravity_force = np.array([0, 0, -mass * self.gravity])
        
        # 总力
        total_force = forces + gravity_force
        
        # 状态导数
        dxdt = np.zeros_like(state)
        dxdt[0:3] = state[3:6]  # 位置导数 = 速度
        dxdt[3:6] = total_force / mass  # 速度导数 = 加速度
        
        # 姿态导数 (简化的欧拉角导数)
        dxdt[6] = p  # pitch rate
        dxdt[7] = q  # roll rate  
        dxdt[8] = r  # yaw rate
        
        # 角加速度 (简化的刚体动力学)
        I = np.diag([0.01, 0.02, 0.015])  # 简化的惯性矩
        dxdt[9:12] = np.linalg.inv(I) @ moments  # 角加速度
        
        return dxdt
    
    def _calculate_aerodynamic_forces(self, airspeed: float, alpha: float, 
                                    beta: float, aero_coeffs: Dict, 
                                    mass: float) -> Tuple[np.ndarray, np.ndarray]:
        """
        计算气动力和力矩
        
        Args:
            airspeed: 空速
            alpha: 攻角
            beta: 侧滑角
            aero_coeffs: 气动系数
            mass: 质量
            
        Returns:
            气动力和力矩
        """
        # 动态压力
        q_dynamic = 0.5 * self.air_density * airspeed**2
        
        # 升力系数 (随攻角变化)
        CL0 = aero_coeffs['CL0']
        CLa = aero_coeffs['CLa']
        CL_max = aero_coeffs['CL_max']
        
        # 限制攻角范围
        alpha_eff = max(min(alpha, math.radians(20)), math.radians(-10))
        CL = CL0 + CLa * alpha_eff
        
        # 阻力系数
        CD0 = aero_coeffs['CD0']
        CD_alpha = aero_coeffs['CD_alpha']
        CD = CD0 + CD_alpha * alpha_eff**2
        
        # 侧力系数
        CY_beta = aero_coeffs['CY_beta']
        CY = CY_beta * beta
        
        # 计算气动力 (在风轴系)
        L = q_dynamic * aero_coeffs['S'] * CL  # 升力
        D = q_dynamic * aero_coeffs['S'] * CD  # 阻力
        Y = q_dynamic * aero_coeffs['S'] * CY  # 侧力
        
        # 转换到体轴系
        forces_body = np.array([
            -D * math.cos(alpha) + L * math.sin(alpha),  # X轴力
            Y,                                           # Y轴力  
            -D * math.sin(alpha) - L * math.cos(alpha)   # Z轴力
        ])
        
        # 简化的气动力矩
        moments = np.array([
            q_dynamic * aero_coeffs['S'] * aero_coeffs['b'] * aero_coeffs['Cl_beta'] * beta,  # 滚转力矩
            q_dynamic * aero_coeffs['S'] * aero_coeffs['c'] * aero_coeffs['Cm_alpha'] * alpha_eff,  # 俯仰力矩
            q_dynamic * aero_coeffs['S'] * aero_coeffs['b'] * aero_coeffs['Cn_beta'] * beta   # 偏航力矩
        ])
        
        return forces_body, moments
    
    def _calculate_mass(self, geometry: Dict) -> float:
        """计算纸飞机质量 (假设A4纸密度)"""
        paper_density = 80.0  # g/m²
        area = geometry['surface_area'] / 10000  # 转换为m²
        return paper_density * area / 1000  # 转换为kg
    
    def _calculate_aerodynamic_coefficients(self, geometry: Dict) -> Dict:
        """
        根据几何形状计算气动系数
        
        Args:
            geometry: 几何信息
            
        Returns:
            气动系数字典
        """
        # 基于几何特征的简化气动系数计算
        vertices = np.array(geometry['vertices'])
        wing_span = np.max(vertices[:, 0]) - np.min(vertices[:, 0])  # x方向跨度
        chord_length = np.max(vertices[:, 1]) - np.min(vertices[:, 1])  # y方向跨度
        aspect_ratio = wing_span / chord_length if chord_length > 0 else 1.0
        
        # 基本气动系数
        coeffs = {
            'S': geometry['surface_area'] / 10000,  # 机翼面积 (m²)
            'b': wing_span / 100,  # 翼展 (m)
            'c': chord_length / 100,  # 平均气动弦长 (m)
            'CL0': 0.1,  # 零升力系数
            'CLa': 2 * math.pi / (1 + 2 / aspect_ratio),  # 升力线斜率
            'CL_max': 1.2,  # 最大升力系数
            'CD0': 0.02,  # 零升阻力系数
            'CD_alpha': 0.1,  # 攻角阻力系数
            'CY_beta': -0.5,  # 侧力系数
            'Cl_beta': -0.1,  # 滚转力矩系数
            'Cm_alpha': -0.5,  # 俯仰力矩系数
            'Cn_beta': 0.1,  # 偏航力矩系数
        }
        
        return coeffs
    
    def _get_wind_velocity(self, altitude: float, wind_conditions: Dict) -> np.ndarray:
        """
        获取指定高度的风速
        
        Args:
            altitude: 高度
            wind_conditions: 风况参数
            
        Returns:
            风速向量
        """
        base_wind = np.array(wind_conditions['velocity'])
        wind_gradient = wind_conditions.get('gradient', 0.0)
        
        # 简单的风速随高度变化模型
        adjusted_wind = base_wind * (1 + wind_gradient * altitude / 10.0)
        
        # 添加湍流
        turbulence = wind_conditions.get('turbulence', 0.0)
        if turbulence > 0:
            turbulence_component = np.random.normal(0, turbulence, 3)
            adjusted_wind += turbulence_component
            
        return adjusted_wind
    
    def _process_simulation_results(self, solution, plane_geometry: Dict) -> Dict:
        """
        处理仿真结果
        
        Args:
            solution: 求解器结果
            plane_geometry: 纸飞机几何信息
            
        Returns:
            处理后的结果字典
        """
        # 提取轨迹
        trajectory = solution.y[0:3].T  # x, y, z 位置
        velocities = solution.y[3:6].T  # 速度
        
        # 计算飞行距离
        horizontal_distance = np.sqrt(trajectory[:, 0]**2 + trajectory[:, 1]**2)
        max_distance = np.max(horizontal_distance)
        
        # 计算飞行时间 (直到触地)
        ground_contact_idx = np.where(trajectory[:, 2] <= 0)[0]
        if len(ground_contact_idx) > 0:
            flight_time = solution.t[ground_contact_idx[0]]
        else:
            flight_time = solution.t[-1]
            
        # 计算稳定性指标
        stability = self._calculate_stability_metrics(solution.y, solution.t)
        
        return {
            'trajectory': trajectory,
            'velocities': velocities,
            'time': solution.t,
            'flight_distance': max_distance,
            'flight_time': flight_time,
            'stability_metrics': stability,
            'final_orientation': solution.y[6:9, -1],  # 最终姿态
            'success': flight_time > 1.0  # 飞行时间超过1秒认为成功
        }
    
    def _calculate_stability_metrics(self, state_history: np.ndarray, time: np.ndarray) -> Dict:
        """
        计算稳定性指标
        
        Args:
            state_history: 状态历史
            time: 时间序列
            
        Returns:
            稳定性指标字典
        """
        # 提取姿态角
        pitch = state_history[6, :]
        roll = state_history[7, :]
        yaw = state_history[8, :]
        
        # 计算振荡幅度
        pitch_amplitude = np.max(pitch) - np.min(pitch)
        roll_amplitude = np.max(roll) - np.min(roll)
        yaw_amplitude = np.max(yaw) - np.min(yaw)
        
        # 计算阻尼比 (简化的方法)
        if len(pitch) > 10:
            # 使用峰值检测计算阻尼
            peaks = self._find_peaks(pitch)
            if len(peaks) >= 2:
                peak_values = pitch[peaks]
                damping_ratio = -np.log(peak_values[1] / peak_values[0]) / (2 * math.pi)
            else:
                damping_ratio = 1.0  # 过阻尼
        else:
            damping_ratio = 1.0
            
        return {
            'pitch_stability': 1.0 / (pitch_amplitude + 0.1),  # 振幅越小越稳定
            'roll_stability': 1.0 / (roll_amplitude + 0.1),
            'yaw_stability': 1.0 / (yaw_amplitude + 0.1),
            'damping_ratio': damping_ratio,
            'overall_stability': 1.0 / (pitch_amplitude + roll_amplitude + yaw_amplitude + 0.3)
        }
    
    def _find_peaks(self, signal: np.ndarray) -> List[int]:
        """简单的峰值检测"""
        peaks = []
        for i in range(1, len(signal)-1):
            if signal[i] > signal[i-1] and signal[i] > signal[i+1]:
                peaks.append(i)
        return peaks
    
    def test_multiple_conditions(self, plane_params: Dict, 
                               test_conditions: List[Dict]) -> Dict:
        """
        在多种条件下测试纸飞机
        
        Args:
            plane_params: 纸飞机参数
            test_conditions: 测试条件列表
            
        Returns:
            多条件测试结果
        """
        results = {}
        
        for i, conditions in enumerate(test_conditions):
            # 生成几何形状
            from .paper_plane_generator import PaperPlaneGenerator
            generator = PaperPlaneGenerator()
            geometry = generator.get_plane_geometry(plane_params)
            
            # 设置初始条件
            initial_conditions = {
                'position': [0, 0, conditions.get('launch_height', 2.0)],
                'velocity': [conditions.get('launch_speed', 5.0), 0, 0],
                'orientation': [conditions.get('launch_angle', 0), 0, 0]
            }
            
            # 设置风况
            wind_conditions = {
                'velocity': conditions.get('wind_velocity', [0, 0, 0]),
                'gradient': conditions.get('wind_gradient', 0.0),
                'turbulence': conditions.get('turbulence', 0.0)
            }
            
            # 运行仿真
            result = self.simulate_flight(
                geometry, initial_conditions, wind_conditions,
                conditions.get('simulation_time', 10.0)
            )
            
            results[f'test_{i}'] = {
                'conditions': conditions,
                'result': result
            }
            
        return results
