"""
纸飞机折叠动画模块
提供动态的折叠过程演示
"""

import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
from typing import Dict, List, Tuple
import matplotlib.patches as patches

class FoldAnimation:
    """纸飞机折叠动画类"""
    
    def __init__(self):
        """初始化动画工具"""
        self.fig = None
        self.ax = None
        self.animation = None
        
    def create_fold_animation(self, plane_params: Dict, 
                            save_path: str = None,
                            fps: int = 10):
        """
        创建纸飞机折叠动画
        
        Args:
            plane_params: 纸飞机参数
            save_path: 保存路径 (可选)
            fps: 帧率
        """
        # 设置图形
        self.fig, self.ax = plt.subplots(figsize=(8, 11))
        self.ax.set_xlim(-1, 22)
        self.ax.set_ylim(-1, 30)
        self.ax.set_aspect('equal')
        self.ax.set_title(f"{plane_params['type']} Paper Plane Folding Animation", fontsize=14)
        self.ax.grid(True, alpha=0.3)
        
        # 绘制纸张边界
        paper_width = 21.0
        paper_height = 29.7
        paper = patches.Rectangle((0, 0), paper_width, paper_height, 
                                fill=False, edgecolor='black', linewidth=2)
        self.ax.add_patch(paper)
        
        # 获取折叠线
        fold_lines = plane_params['fold_lines']
        
        # 创建动画
        self.animation = animation.FuncAnimation(
            self.fig, 
            self._animate_fold,
            frames=len(fold_lines) + 5,  # 额外帧用于延迟
            fargs=(fold_lines, paper_width, paper_height),
            interval=1000//fps,
            blit=False,
            repeat=True
        )
        
        if save_path:
            # 保存为GIF
            self.animation.save(save_path, writer='pillow', fps=fps)
            print(f"动画已保存到: {save_path}")
        
        plt.show()
        return self.animation
    
    def _animate_fold(self, frame: int, fold_lines: List, 
                     paper_width: float, paper_height: float):
        """
        动画帧更新函数
        
        Args:
            frame: 当前帧
            fold_lines: 折叠线列表
            paper_width: 纸张宽度
            paper_height: 纸张高度
        """
        # 清除之前的线条
        self.ax.clear()
        self.ax.set_xlim(-1, 22)
        self.ax.set_ylim(-1, 30)
        self.ax.set_aspect('equal')
        self.ax.grid(True, alpha=0.3)
        
        # 重新绘制纸张
        paper = patches.Rectangle((0, 0), paper_width, paper_height, 
                                fill=False, edgecolor='black', linewidth=2)
        self.ax.add_patch(paper)
        
        # 根据帧数绘制折叠线
        lines_to_draw = min(frame, len(fold_lines))
        
        for i in range(lines_to_draw):
            fold_name, x1, y1, x2, y2 = fold_lines[i]
            
            # 转换为实际坐标
            x1_actual = x1 * paper_width
            y1_actual = y1 * paper_height
            x2_actual = x2 * paper_width
            y2_actual = y2 * paper_height
            
            # 绘制折叠线
            line, = self.ax.plot([x1_actual, x2_actual], [y1_actual, y2_actual], 
                               'r--', linewidth=2, alpha=0.8)
            
            # 添加标签（只在最后一帧显示所有标签）
            if frame >= len(fold_lines):
                mid_x = (x1_actual + x2_actual) / 2
                mid_y = (y1_actual + y2_actual) / 2
                self.ax.text(mid_x, mid_y, fold_name, fontsize=8, 
                           bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.8))
        
        # 添加进度指示
        progress = min(frame / len(fold_lines), 1.0)
        self.ax.text(1, 28, f'Progress: {progress*100:.0f}%', 
                    fontsize=10, bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue"))
        
        return []
    
    def create_step_by_step_folding(self, plane_params: Dict, 
                                  save_dir: str = None):
        """
        创建分步折叠演示
        
        Args:
            plane_params: 纸飞机参数
            save_dir: 保存目录 (可选)
        """
        fold_lines = plane_params['fold_lines']
        paper_width = 21.0
        paper_height = 29.7
        
        # 为每个步骤创建单独的图像
        for step in range(len(fold_lines) + 1):
            fig, ax = plt.subplots(figsize=(8, 11))
            ax.set_xlim(-1, 22)
            ax.set_ylim(-1, 30)
            ax.set_aspect('equal')
            ax.set_title(f"Step {step}: {plane_params['type']} Paper Plane", fontsize=14)
            ax.grid(True, alpha=0.3)
            
            # 绘制纸张
            paper = patches.Rectangle((0, 0), paper_width, paper_height, 
                                    fill=False, edgecolor='black', linewidth=2)
            ax.add_patch(paper)
            
            # 绘制当前步骤的折叠线
            for i in range(step):
                fold_name, x1, y1, x2, y2 = fold_lines[i]
                
                x1_actual = x1 * paper_width
                y1_actual = y1 * paper_height
                x2_actual = x2 * paper_width
                y2_actual = y2 * paper_height
                
                ax.plot([x1_actual, x2_actual], [y1_actual, y2_actual], 
                       'r--', linewidth=2)
                
                # 添加标签
                mid_x = (x1_actual + x2_actual) / 2
                mid_y = (y1_actual + y2_actual) / 2
                ax.text(mid_x, mid_y, fold_name, fontsize=8, 
                       bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.8))
            
            # 添加步骤说明
            if step == 0:
                instruction = "Start with A4 paper"
            elif step < len(fold_lines):
                instruction = f"Fold: {fold_lines[step-1][0]}"
            else:
                instruction = "Folding complete!"
            
            ax.text(1, 28, instruction, fontsize=10, 
                   bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgreen"))
            
            plt.tight_layout()
            
            if save_dir:
                # 确保目录存在
                import os
                os.makedirs(save_dir, exist_ok=True)
                plt.savefig(f"{save_dir}/step_{step:02d}.png", dpi=150, bbox_inches='tight')
            
            plt.close(fig)
        
        if save_dir:
            print(f"分步折叠图已保存到: {save_dir}")
    
    def create_3d_folding_demo(self, plane_params: Dict):
        """
        创建3D折叠演示（概念性）
        
        Args:
            plane_params: 纸飞机参数
        """
        # 这是一个概念性的3D演示
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # 创建简单的3D纸飞机形状
        vertices = np.array(plane_params['vertices'])
        
        # 将2D顶点转换为3D
        vertices_3d = np.column_stack([vertices[:, 0], vertices[:, 1], np.zeros(len(vertices))])
        
        # 绘制3D形状
        ax.plot_trisurf(vertices_3d[:, 0], vertices_3d[:, 1], vertices_3d[:, 2], 
                       alpha=0.6, color='lightblue')
        
        ax.set_xlabel('X (cm)')
        ax.set_ylabel('Y (cm)')
        ax.set_zlabel('Z (cm)')
        ax.set_title(f"3D View: {plane_params['type']} Paper Plane")
        
        plt.show()

def create_folding_instructions(plane_params: Dict) -> str:
    """
    生成详细的折叠说明
    
    Args:
        plane_params: 纸飞机参数
        
    Returns:
        折叠说明文本
    """
    fold_lines = plane_params['fold_lines']
    instructions = []
    
    instructions.append(f"# {plane_params['type'].title()} Paper Plane Folding Instructions")
    instructions.append("")
    instructions.append("## Materials Needed:")
    instructions.append("- One sheet of A4 paper (21cm × 29.7cm)")
    instructions.append("")
    instructions.append("## Folding Steps:")
    
    for i, (fold_name, x1, y1, x2, y2) in enumerate(fold_lines, 1):
        instructions.append(f"### Step {i}: {fold_name}")
        
        # 根据折叠线类型提供具体说明
        if "center" in fold_name.lower():
            instructions.append("1. Fold the paper in half along the center line")
            instructions.append("2. Crease firmly and unfold")
        elif "corner" in fold_name.lower():
            instructions.append("1. Fold the corner to the marked point")
            instructions.append("2. Make a sharp crease")
        elif "wing" in fold_name.lower():
            instructions.append("1. Fold the wing along the indicated line")
            instructions.append("2. Ensure both sides are symmetrical")
        elif "nose" in fold_name.lower():
            instructions.append("1. Fold the nose section")
            instructions.append("2. This creates the plane's front")
        else:
            instructions.append("1. Follow the marked fold line")
            instructions.append("2. Crease well for better flight performance")
        
        instructions.append("")
    
    instructions.append("## Final Steps:")
    instructions.append("1. Check all folds are crisp and clean")
    instructions.append("2. Ensure symmetry on both sides")
    instructions.append("3. Make any final adjustments")
    instructions.append("4. Your paper plane is ready to fly!")
    instructions.append("")
    instructions.append(f"**Expected Performance:**")
    instructions.append(f"- Wing Span: {plane_params['wing_span']:.1f} cm")
    instructions.append(f"- Body Length: {plane_params['body_length']:.1f} cm")
    instructions.append(f"- Best for: {plane_params.get('description', 'general flying')}")
    
    return "\n".join(instructions)
