"""
可视化模块
提供纸飞机仿真结果的可视化功能
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List, Optional
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import matplotlib.patches as patches
from mpl_toolkits.mplot3d import Axes3D

class Visualization:
    """可视化工具类"""
    
    def __init__(self):
        """初始化可视化工具"""
        plt.style.use('seaborn-v0_8')
        self.colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    
    def plot_optimization_progress(self, optimization_result: Dict, 
                                 save_path: Optional[str] = None):
        """
        绘制优化进度图
        
        Args:
            optimization_result: 优化结果
            save_path: 保存路径 (可选)
        """
        best_fitness = optimization_result['best_fitness_history']
        avg_fitness = optimization_result['avg_fitness_history']
        generations = range(len(best_fitness))
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        ax.plot(generations, best_fitness, 'b-', linewidth=2, label='Best Fitness')
        ax.plot(generations, avg_fitness, 'r--', linewidth=2, label='Average Fitness')
        
        ax.set_xlabel('Generation')
        ax.set_ylabel('Fitness')
        ax.set_title('Genetic Algorithm Optimization Progress')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def plot_flight_trajectory(self, simulation_results: Dict, 
                             condition_name: str = '无风',
                             save_path: Optional[str] = None):
        """
        绘制飞行轨迹
        
        Args:
            simulation_results: 仿真结果
            condition_name: 条件名称
            save_path: 保存路径 (可选)
        """
        result = simulation_results[condition_name]
        trajectory = result['trajectory']
        
        fig = plt.figure(figsize=(15, 5))
        
        # 2D 轨迹图
        ax1 = fig.add_subplot(131)
        ax1.plot(trajectory[:, 0], trajectory[:, 2], 'b-', linewidth=2)
        ax1.set_xlabel('Horizontal Distance (m)')
        ax1.set_ylabel('Altitude (m)')
        ax1.set_title(f'{condition_name} - Flight Trajectory')
        ax1.grid(True, alpha=0.3)
        ax1.set_aspect('equal')
        
        # 3D 轨迹图
        ax2 = fig.add_subplot(132, projection='3d')
        ax2.plot(trajectory[:, 0], trajectory[:, 1], trajectory[:, 2], 'r-', linewidth=2)
        ax2.set_xlabel('X (m)')
        ax2.set_ylabel('Y (m)')
        ax2.set_zlabel('Z (m)')
        ax2.set_title(f'{condition_name} - 3D Trajectory')
        
        # 速度变化图
        ax3 = fig.add_subplot(133)
        time = np.arange(len(trajectory)) * 0.01  # 假设时间步长为0.01秒
        speed = np.linalg.norm(result['velocities'], axis=1)
        ax3.plot(time, speed, 'g-', linewidth=2)
        ax3.set_xlabel('Time (s)')
        ax3.set_ylabel('Speed (m/s)')
        ax3.set_title(f'{condition_name} - Speed Variation')
        ax3.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def plot_plane_comparison(self, plane_params_list: List[Dict], 
                            simulation_results_list: List[Dict],
                            save_path: Optional[str] = None):
        """
        比较多个纸飞机的性能
        
        Args:
            plane_params_list: 纸飞机参数列表
            simulation_results_list: 仿真结果列表
            save_path: 保存路径 (可选)
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # 提取性能指标
        distances = []
        flight_times = []
        stabilities = []
        plane_types = []
        
        for i, (params, results) in enumerate(zip(plane_params_list, simulation_results_list)):
            # 计算平均性能
            flight_distances = []
            flight_times_list = []
            stabilities_list = []
            
            for test_name, test_result in results.items():
                result = test_result['result']
                flight_distances.append(result['flight_distance'])
                flight_times_list.append(result['flight_time'])
                stabilities_list.append(result['stability_metrics']['overall_stability'])
            
            avg_distance = np.mean(flight_distances)
            avg_time = np.mean(flight_times_list)
            avg_stability = np.mean(stabilities_list)
            
            distances.append(avg_distance)
            flight_times.append(avg_time)
            stabilities.append(avg_stability)
            plane_types.append(params['type'])
        
        # 飞行距离比较
        axes[0, 0].bar(range(len(distances)), distances, color=self.colors[:len(distances)])
        axes[0, 0].set_xlabel('Paper Plane Type')
        axes[0, 0].set_ylabel('Average Flight Distance (m)')
        axes[0, 0].set_title('Flight Distance Comparison')
        axes[0, 0].set_xticks(range(len(plane_types)))
        axes[0, 0].set_xticklabels(plane_types, rotation=45)
        
        # 飞行时间比较
        axes[0, 1].bar(range(len(flight_times)), flight_times, color=self.colors[:len(flight_times)])
        axes[0, 1].set_xlabel('Paper Plane Type')
        axes[0, 1].set_ylabel('Average Flight Time (s)')
        axes[0, 1].set_title('Flight Time Comparison')
        axes[0, 1].set_xticks(range(len(plane_types)))
        axes[0, 1].set_xticklabels(plane_types, rotation=45)
        
        # 稳定性比较
        axes[1, 0].bar(range(len(stabilities)), stabilities, color=self.colors[:len(stabilities)])
        axes[1, 0].set_xlabel('Paper Plane Type')
        axes[1, 0].set_ylabel('Average Stability')
        axes[1, 0].set_title('Stability Comparison')
        axes[1, 0].set_xticks(range(len(plane_types)))
        axes[1, 0].set_xticklabels(plane_types, rotation=45)
        
        # 雷达图比较
        axes[1, 1].axis('off')  # 隐藏第四个子图，为雷达图留位置
        
        # 创建雷达图
        radar_fig = plt.figure(figsize=(8, 6))
        radar_ax = radar_fig.add_subplot(111, polar=True)
        
        # 归一化数据
        norm_distances = [d/max(distances) for d in distances]
        norm_times = [t/max(flight_times) for t in flight_times]
        norm_stabilities = [s/max(stabilities) for s in stabilities]
        
        # 雷达图角度
        categories = ['Flight Distance', 'Flight Time', 'Stability']
        N = len(categories)
        angles = [n / float(N) * 2 * np.pi for n in range(N)]
        angles += angles[:1]  # 闭合图形
        
        for i, (d, t, s) in enumerate(zip(norm_distances, norm_times, norm_stabilities)):
            values = [d, t, s]
            values += values[:1]  # 闭合图形
            radar_ax.plot(angles, values, 'o-', linewidth=2, label=plane_types[i], color=self.colors[i])
            radar_ax.fill(angles, values, alpha=0.1, color=self.colors[i])
        
        radar_ax.set_xticks(angles[:-1])
        radar_ax.set_xticklabels(categories)
        radar_ax.set_ylim(0, 1)
        radar_ax.set_title('Performance Radar Chart Comparison')
        radar_ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            radar_fig.savefig(save_path.replace('.png', '_radar.png'), dpi=300, bbox_inches='tight')
        
        plt.show()
        radar_fig.show()
    
    def plot_fold_pattern(self, plane_params: Dict, save_path: Optional[str] = None):
        """
        绘制纸飞机折叠图案
        
        Args:
            plane_params: 纸飞机参数
            save_path: 保存路径 (可选)
        """
        fig, ax = plt.subplots(figsize=(8, 11))  # A4纸比例
        
        # 绘制纸张边界
        paper_width = 21.0  # cm
        paper_height = 29.7  # cm
        ax.add_patch(patches.Rectangle((0, 0), paper_width, paper_height, 
                                     fill=False, edgecolor='black', linewidth=2))
        
        # 绘制折叠线
        fold_lines = plane_params['fold_lines']
        for fold_name, x1, y1, x2, y2 in fold_lines:
            # 转换为实际坐标
            x1_actual = x1 * paper_width
            y1_actual = y1 * paper_height
            x2_actual = x2 * paper_width
            y2_actual = y2 * paper_height
            
            # 绘制折叠线
            ax.plot([x1_actual, x2_actual], [y1_actual, y2_actual], 
                   'r--', linewidth=2, label=fold_name)
            
            # 添加标签
            mid_x = (x1_actual + x2_actual) / 2
            mid_y = (y1_actual + y2_actual) / 2
            ax.text(mid_x, mid_y, fold_name, fontsize=10, 
                   bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))
        
        # 添加关键尺寸标注
        wing_span = plane_params['wing_span']
        body_length = plane_params['body_length']
        
        ax.annotate(f'Wing Span: {wing_span:.1f}cm', 
                   xy=(paper_width/2, paper_height*0.3), 
                   xytext=(paper_width/2, paper_height*0.4),
                   arrowprops=dict(arrowstyle='->', color='blue'),
                   fontsize=12, ha='center')
        
        ax.annotate(f'Body Length: {body_length:.1f}cm', 
                   xy=(paper_width/2, paper_height*0.7), 
                   xytext=(paper_width/2, paper_height*0.8),
                   arrowprops=dict(arrowstyle='->', color='green'),
                   fontsize=12, ha='center')
        
        ax.set_xlim(-1, paper_width + 1)
        ax.set_ylim(-1, paper_height + 1)
        ax.set_aspect('equal')
        ax.set_title(f"{plane_params['type']} Paper Plane Fold Pattern", fontsize=14)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def create_interactive_dashboard(self, optimization_result: Dict):
        """
        创建交互式仪表板
        
        Args:
            optimization_result: 优化结果
        """
        best_individual = optimization_result['best_individual']
        detailed_eval = optimization_result['detailed_evaluation']
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=3,
            subplot_titles=('优化进度', '各条件飞行距离', '各条件稳定性',
                          '关键参数', '性能雷达图', '最佳纸飞机类型'),
            specs=[[{"type": "xy"}, {"type": "bar"}, {"type": "bar"}],
                   [{"type": "bar"}, {"type": "polar"}, {"type": "pie"}]]
        )
        
        # 1. 优化进度图
        generations = range(len(optimization_result['best_fitness_history']))
        fig.add_trace(
            go.Scatter(x=list(generations), y=optimization_result['best_fitness_history'],
                      name='最佳适应度', line=dict(color='blue')),
            row=1, col=1
        )
        fig.add_trace(
            go.Scatter(x=list(generations), y=optimization_result['avg_fitness_history'],
                      name='平均适应度', line=dict(color='red', dash='dash')),
            row=1, col=1
        )
        
        # 2. 各条件飞行距离
        conditions = list(detailed_eval.keys())
        distances = [detailed_eval[cond]['flight_distance'] for cond in conditions]
        fig.add_trace(
            go.Bar(x=conditions, y=distances, name='飞行距离'),
            row=1, col=2
        )
        
        # 3. 各条件稳定性
        stabilities = [detailed_eval[cond]['stability_metrics']['overall_stability'] for cond in conditions]
        fig.add_trace(
            go.Bar(x=conditions, y=stabilities, name='稳定性'),
            row=1, col=3
        )
        
        # 4. 关键参数
        key_params = ['翼展', '机身长度', '鼻角', '重量分布']
        param_values = [
            best_individual['wing_span'],
            best_individual['body_length'],
            best_individual['nose_angle'],
            best_individual['weight_distribution'] * 100
        ]
        fig.add_trace(
            go.Bar(x=key_params, y=param_values, name='参数值'),
            row=2, col=1
        )
        
        # 5. 性能雷达图
        categories = ['飞行距离', '飞行时间', '稳定性', '成功率']
        # 归一化数据
        norm_distances = [d/max(distances) for d in distances]
        norm_times = [detailed_eval[cond]['flight_time']/max([detailed_eval[c]['flight_time'] for c in conditions]) for cond in conditions]
        norm_stabilities = [s/max(stabilities) for s in stabilities]
        success_rates = [1.0 if detailed_eval[cond]['success'] else 0.0 for cond in conditions]
        
        # 计算平均性能
        avg_performance = [
            np.mean(norm_distances),
            np.mean(norm_times),
            np.mean(norm_stabilities),
            np.mean(success_rates)
        ]
        avg_performance += avg_performance[:1]  # 闭合图形
        
        theta = np.linspace(0, 2*np.pi, len(categories) + 1)
        fig.add_trace(
            go.Scatterpolar(r=avg_performance, theta=theta,
                          fill='toself', name='平均性能'),
            row=2, col=2
        )
        
        # 6. 最佳纸飞机类型
        plane_type = best_individual['type']
        type_counts = {pt: 0 for pt in ['classic', 'delta', 'glider', 'stunt', 'long_distance']}
        type_counts[plane_type] = 1
        
        fig.add_trace(
            go.Pie(labels=list(type_counts.keys()), values=list(type_counts.values()),
                  name='最佳类型'),
            row=2, col=3
        )
        
        # 更新布局
        fig.update_layout(
            height=800,
            title_text="Sigma PaperPlane 优化结果仪表板",
            showlegend=True
        )
        
        fig.show()
    
    def generate_optimization_report(self, optimization_result: Dict, 
                                   save_path: Optional[str] = None):
        """
        生成优化报告
        
        Args:
            optimization_result: 优化结果
            save_path: 保存路径 (可选)
        """
        summary = optimization_result.get('optimization_summary', {})
        best_individual = optimization_result['best_individual']
        detailed_eval = optimization_result['detailed_evaluation']
        
        # 创建报告文本
        report = f"""
# Sigma PaperPlane 优化报告

## 最佳纸飞机配置

- **类型**: {best_individual['type']}
- **翼展**: {best_individual['wing_span']:.1f} cm
- **机身长度**: {best_individual['body_length']:.1f} cm  
- **鼻角**: {best_individual['nose_angle']:.1f} 度
- **重量分布**: {best_individual['weight_distribution']*100:.1f}%

## 性能表现

"""
        
        # 添加各条件性能
        for condition, result in detailed_eval.items():
            report += f"""
### {condition}条件
- 飞行距离: {result['flight_distance']:.2f} m
- 飞行时间: {result['flight_time']:.2f} s
- 稳定性: {result['stability_metrics']['overall_stability']:.3f}
- 飞行成功: {'是' if result['success'] else '否'}
"""
        
        # 添加优化统计
        report += f"""
## 优化统计

- 最终适应度: {optimization_result['best_fitness']:.3f}
- 进化代数: {len(optimization_result['best_fitness_history'])}
- 最佳适应度提升: {optimization_result['best_fitness_history'][-1] - optimization_result['best_fitness_history'][0]:.3f}
"""
        
        # 保存报告
        if save_path:
            with open(save_path, 'w', encoding='utf-8') as f:
                f.write(report)
        
        return report
