"""
Sigma PaperPlane 动画演示
展示动态折叠过程和详细说明
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from src.paper_plane_generator import PaperPlaneGenerator
from src.animation import FoldAnimation, create_folding_instructions
import matplotlib.pyplot as plt

def demo_animation():
    """演示动画功能"""
    print("=== Sigma PaperPlane 动画演示 ===")
    
    # 创建纸飞机生成器和动画工具
    generator = PaperPlaneGenerator()
    animator = FoldAnimation()
    
    # 演示不同类型的纸飞机
    plane_types = ['classic', 'delta', 'glider', 'stunt', 'long_distance']
    
    for plane_type in plane_types:
        print(f"\n演示 {plane_type} 纸飞机:")
        print("-" * 40)
        
        # 生成纸飞机
        if plane_type == 'classic':
            plane = generator._generate_classic_plane()
        elif plane_type == 'delta':
            plane = generator._generate_delta_plane()
        elif plane_type == 'glider':
            plane = generator._generate_glider_plane()
        elif plane_type == 'stunt':
            plane = generator._generate_stunt_plane()
        else:
            plane = generator._generate_long_distance_plane()
        
        # 显示基本信息
        print(f"翼展: {plane['wing_span']:.1f} cm")
        print(f"机身长度: {plane['body_length']:.1f} cm")
        print(f"折叠步骤数: {len(plane['fold_lines'])}")
        
        # 生成折叠说明
        instructions = create_folding_instructions(plane)
        print("\n折叠说明:")
        print("-" * 20)
        
        # 只打印前几步说明
        lines = instructions.split('\n')
        for i, line in enumerate(lines[:15]):  # 只显示前15行
            if line.strip():
                print(line)
        
        if len(lines) > 15:
            print("... (完整说明已保存到文件)")
        
        # 保存折叠说明到文件
        instructions_file = f"folding_instructions_{plane_type}.txt"
        with open(instructions_file, 'w', encoding='utf-8') as f:
            f.write(instructions)
        print(f"完整折叠说明已保存到: {instructions_file}")
        
        # 创建分步折叠图
        print(f"生成分步折叠图...")
        steps_dir = f"folding_steps_{plane_type}"
        os.makedirs(steps_dir, exist_ok=True)
        animator.create_step_by_step_folding(plane, steps_dir)
        
        # 询问是否显示动画
        print(f"\n是否显示 {plane_type} 纸飞机的折叠动画? (y/n)")
        user_input = input().strip().lower()
        
        if user_input == 'y':
            print("正在创建动画... (可能需要几秒钟)")
            try:
                # 创建动画
                animator.create_fold_animation(plane)
                print("动画演示完成!")
            except Exception as e:
                print(f"动画创建失败: {e}")
                print("请确保已安装必要的依赖: pip install pillow")
        
        print("-" * 40)

def demo_best_plane_animation():
    """演示最佳纸飞机的动画"""
    print("\n=== 最佳纸飞机动画演示 ===")
    
    # 这里可以集成优化结果
    # 为了演示，我们使用 long_distance 纸飞机
    generator = PaperPlaneGenerator()
    animator = FoldAnimation()
    
    # 生成长距离纸飞机
    best_plane = generator._generate_long_distance_plane()
    
    print("最佳纸飞机配置:")
    print(f"类型: {best_plane['type']}")
    print(f"翼展: {best_plane['wing_span']:.1f} cm")
    print(f"机身长度: {best_plane['body_length']:.1f} cm")
    print(f"折叠步骤: {len(best_plane['fold_lines'])}")
    
    # 生成详细的折叠说明
    instructions = create_folding_instructions(best_plane)
    print("\n详细折叠说明:")
    print("-" * 30)
    
    # 打印关键步骤
    lines = instructions.split('\n')
    for line in lines:
        if line.startswith('### Step') or line.startswith('## Final'):
            print(line)
    
    # 保存完整说明
    with open("best_plane_instructions.txt", 'w', encoding='utf-8') as f:
        f.write(instructions)
    print(f"\n完整说明已保存到: best_plane_instructions.txt")
    
    # 创建分步图
    print("生成分步折叠图...")
    animator.create_step_by_step_folding(best_plane, "best_plane_steps")
    
    # 创建动画
    print("创建折叠动画...")
    try:
        animator.create_fold_animation(best_plane)
        print("动画演示完成!")
    except Exception as e:
        print(f"动画创建失败: {e}")
        print("请确保已安装必要的依赖: pip install pillow")

def create_complete_demonstration():
    """创建完整的演示包"""
    print("\n=== 创建完整演示包 ===")
    
    generator = PaperPlaneGenerator()
    animator = FoldAnimation()
    
    # 创建演示目录
    demo_dir = "paper_plane_demonstration"
    os.makedirs(demo_dir, exist_ok=True)
    
    print(f"创建演示包到目录: {demo_dir}")
    
    plane_types = ['classic', 'delta', 'glider', 'stunt', 'long_distance']
    
    for plane_type in plane_types:
        print(f"处理 {plane_type} 纸飞机...")
        
        # 生成纸飞机
        if plane_type == 'classic':
            plane = generator._generate_classic_plane()
        elif plane_type == 'delta':
            plane = generator._generate_delta_plane()
        elif plane_type == 'glider':
            plane = generator._generate_glider_plane()
        elif plane_type == 'stunt':
            plane = generator._generate_stunt_plane()
        else:
            plane = generator._generate_long_distance_plane()
        
        # 创建子目录
        plane_dir = os.path.join(demo_dir, plane_type)
        os.makedirs(plane_dir, exist_ok=True)
        
        # 保存折叠说明
        instructions = create_folding_instructions(plane)
        with open(os.path.join(plane_dir, "folding_instructions.txt"), 'w', encoding='utf-8') as f:
            f.write(instructions)
        
        # 创建分步图
        animator.create_step_by_step_folding(plane, plane_dir)
        
        print(f"  - 已保存到: {plane_dir}/")
    
    print(f"\n演示包创建完成!")
    print(f"包含 {len(plane_types)} 种纸飞机的:")
    print("  - 详细折叠说明")
    print("  - 分步折叠图")
    print("  - 性能参数")

if __name__ == "__main__":
    print("Sigma PaperPlane 动画演示")
    print("=" * 50)
    
    # 运行动画演示
    demo_animation()
    
    # 运行最佳纸飞机演示
    demo_best_plane_animation()
    
    # 创建完整演示包
    create_complete_demonstration()
    
    print("\n" + "=" * 50)
    print("动画演示完成!")
    print("\n生成的文件包括:")
    print("- 各种纸飞机的折叠说明 (*.txt)")
    print("- 分步折叠图 (folding_steps_*/)")
    print("- 完整演示包 (paper_plane_demonstration/)")
    print("\n要查看动画，请运行演示并选择 'y' 来显示动画")
