"""
Sigma PaperPlane 示例演示
展示如何使用各个模块
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from src.paper_plane_generator import PaperPlaneGenerator
from src.fluid_simulation import FluidSimulation
from src.optimization import GeneticOptimizer
from src.visualization import Visualization

def demo_basic_functionality():
    """演示基本功能"""
    print("=== Sigma PaperPlane 基本功能演示 ===")
    
    # 1. 纸飞机生成器演示
    print("\n1. 纸飞机生成器演示")
    generator = PaperPlaneGenerator()
    
    # 生成不同类型的纸飞机
    plane_types = ['classic', 'delta', 'glider', 'stunt', 'long_distance']
    for plane_type in plane_types:
        if plane_type == 'classic':
            plane = generator._generate_classic_plane()
        elif plane_type == 'delta':
            plane = generator._generate_delta_plane()
        elif plane_type == 'glider':
            plane = generator._generate_glider_plane()
        elif plane_type == 'stunt':
            plane = generator._generate_stunt_plane()
        else:
            plane = generator._generate_long_distance_plane()
        
        print(f"  {plane_type}: 翼展={plane['wing_span']:.1f}cm, 机身={plane['body_length']:.1f}cm")
    
    # 2. 流体仿真演示
    print("\n2. 流体仿真演示")
    simulator = FluidSimulation()
    
    # 测试一个经典纸飞机
    classic_plane = generator._generate_classic_plane()
    geometry = generator.get_plane_geometry(classic_plane)
    
    initial_conditions = {
        'position': [0, 0, 2.0],
        'velocity': [6.0, 0, 0],
        'orientation': [10, 0, 0]
    }
    
    wind_conditions = {
        'velocity': [0, 0, 0],
        'gradient': 0.0,
        'turbulence': 0.0
    }
    
    result = simulator.simulate_flight(geometry, initial_conditions, wind_conditions)
    print(f"  飞行距离: {result['flight_distance']:.2f} m")
    print(f"  飞行时间: {result['flight_time']:.2f} s")
    print(f"  稳定性: {result['stability_metrics']['overall_stability']:.3f}")
    
    # 3. 可视化演示
    print("\n3. 可视化演示")
    visualizer = Visualization()
    
    # 显示折叠图案
    print("  生成折叠图案...")
    visualizer.plot_fold_pattern(classic_plane)
    
    print("\n基本功能演示完成！")

def demo_optimization():
    """演示优化功能"""
    print("\n=== 遗传算法优化演示 ===")
    
    # 使用较小的种群和代数进行快速演示
    optimizer = GeneticOptimizer(
        population_size=20,
        mutation_rate=0.1,
        crossover_rate=0.8,
        elite_count=3
    )
    
    print("开始优化...")
    result = optimizer.optimize(
        generations=10,  # 使用较少的代数进行快速演示
        objective='balanced'
    )
    
    # 显示优化结果
    summary = optimizer.get_optimization_summary(result)
    print(f"最佳纸飞机类型: {summary['best_plane_type']}")
    print(f"最终适应度: {summary['best_fitness']:.3f}")
    
    # 显示优化进度
    visualizer = Visualization()
    visualizer.plot_optimization_progress(result)
    
    print("优化演示完成！")

def demo_multiple_conditions():
    """演示多条件测试"""
    print("\n=== 多条件测试演示 ===")
    
    generator = PaperPlaneGenerator()
    simulator = FluidSimulation()
    visualizer = Visualization()
    
    # 生成一个纸飞机
    plane = generator.generate_random_plane()
    print(f"测试纸飞机: {plane['type']}")
    
    # 定义测试条件
    test_conditions = [
        {
            'name': '无风',
            'wind_velocity': [0, 0, 0],
            'launch_speed': 6.0,
            'launch_angle': 10
        },
        {
            'name': '顺风',
            'wind_velocity': [3, 0, 0],
            'launch_speed': 5.0,
            'launch_angle': 5
        },
        {
            'name': '逆风',
            'wind_velocity': [-2, 0, 0],
            'launch_speed': 7.0,
            'launch_angle': 15
        }
    ]
    
    # 运行多条件测试
    results = simulator.test_multiple_conditions(plane, test_conditions)
    
    # 显示结果
    for condition_name, test_result in results.items():
        result = test_result['result']
        print(f"  {condition_name}:")
        print(f"    飞行距离: {result['flight_distance']:.2f} m")
        print(f"    飞行时间: {result['flight_time']:.2f} s")
        print(f"    稳定性: {result['stability_metrics']['overall_stability']:.3f}")
    
    print("多条件测试演示完成！")

if __name__ == "__main__":
    print("Sigma PaperPlane 示例演示")
    print("=" * 50)
    
    # 运行各个演示
    demo_basic_functionality()
    demo_optimization()
    demo_multiple_conditions()
    
    print("\n" + "=" * 50)
    print("所有演示完成！")
    print("\n要运行完整优化，请使用: python main.py --mode optimize --generations 100")
